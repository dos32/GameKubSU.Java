package game.utils;

public class Vector {
	public double x, y;
	
	public Vector()
	{
		this.x=0;
		this.y=0;
	}
	
	public Vector(double x, double y)
	{
		this.x=x;
		this.y=y;
	}
	
	public Vector(Vector prototype)
	{
		this.x=prototype.x;
		this.y=prototype.y;
	}
	
	public double dotprod(Vector v)
	{
		return v.x*this.x+v.y*this.y;
	}
	
	public Vector sum(Vector v)
	{
		return new Vector(this.x+v.x, this.y+v.y);
	}
	
	public double norm()
	{
		return Math.sqrt(this.x*this.x+this.y*this.y);
	}
}
