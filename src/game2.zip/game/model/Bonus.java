package game.model;

import game.utils.Vector;

public class Bonus extends Unit {
	protected BonusType type;
	
	public Bonus(BonusType bonusType)
	{
		type=bonusType;
	}

	@Override
	public double getDepth(Vector v) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Vector getNorm(Vector v) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void getMesh() {
		// TODO Auto-generated method stub
		
	}
}
