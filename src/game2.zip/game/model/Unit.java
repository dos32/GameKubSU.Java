package game.model;

import java.awt.Graphics2D;

import game.utils.*;

public abstract class Unit {
	protected int id;
	protected Vector position;
	protected Vector speed;
	protected double angle;
	protected double angularSpeed;
	protected boolean isStatic;
	protected boolean isMaterial;
	protected double mass;
	
	public int getId()
	{
		return id;
	}
	public Vector getPosition()
	{
		return position;
	}
	public Vector getSpeed()
	{
		return speed;
	}
	public double getAngle()
	{
		return angle;
	}
	public double getAngularSpeed()
	{
		return angularSpeed;
	}
	protected double getMass()
	{
		return mass;
	}
	
	public Unit()
	{
		position=new Vector();
		speed=new Vector();
	}
	
	public Unit(Vector position, Vector speed)
	{
		this.position=position;
		this.speed=speed;
	}
	
	public abstract double getDepth(Unit unit);
	
	public abstract Vector getNorm(Unit unit);
	
	public abstract void Draw(Graphics2D graphics);
}
