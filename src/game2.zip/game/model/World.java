package game.model;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;
import java.util.ArrayList;

public class World implements Externalizable {
	private static final long serialVersionUID = 5624391324336770137L;
	
	public int tick;
	public int playersCount;
	public double width, height;
	public ArrayList<Car> cars=new ArrayList<>();
	public ArrayList<Obstacle> obstacles=new ArrayList<>();
	public ArrayList<Bonus> bonuses=new ArrayList<>();
	//public ArrayList<Player> players;
	
	public static void main(String[] args) {
		//TODO
	}
	
	public void Initialize()
	{
		//TODO
	}
	
	public void tick()
	{
		//TODO
	}

	@SuppressWarnings("unchecked")
	@Override
	public void readExternal(ObjectInput arg0) throws IOException,
			ClassNotFoundException {
		tick=arg0.readInt();
		playersCount=arg0.readInt();
		width=arg0.readDouble();
		height=arg0.readDouble();
		cars=(ArrayList<Car>)arg0.readObject();
		obstacles=(ArrayList<Obstacle>)arg0.readObject();
		bonuses=(ArrayList<Bonus>)arg0.readObject();
	}

	@Override
	public void writeExternal(ObjectOutput arg0) throws IOException {
		arg0.writeInt(tick);
		arg0.writeInt(playersCount);
		arg0.writeDouble(width);
		arg0.writeDouble(height);
		arg0.writeObject(cars);
		arg0.writeObject(obstacles);
		arg0.writeObject(bonuses);
	}

}
