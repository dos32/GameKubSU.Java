package game.model;

import java.awt.Graphics2D;

import game.utils.Vector;

public class CircleShapeUnit extends Unit {

	@Override
	public double getDepth(Unit unit) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Vector getNorm(Unit unit) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Draw(Graphics2D graphics) {
		// TODO Auto-generated method stub
		
	}
}
