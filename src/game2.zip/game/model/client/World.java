package game.model.client;

import java.io.Serializable;

public class World implements Serializable {
	private static final long serialVersionUID = 7045681609858877161L;

	public static void main(String[] args) {
	}

}
