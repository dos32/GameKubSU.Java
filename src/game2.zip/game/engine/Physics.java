package game.engine;

public final class Physics {
	public void tick() {
		
	}
}
