package game.engine;

public class Player {
	protected int id;
	protected String name;
	protected boolean isCrashed;
	protected int score;
}
