package game.engine;

import java.awt.Graphics2D;

public final class Renderer {
	protected boolean updated;
	
	public void render(Graphics2D graphics)
	{
		
	}
}
