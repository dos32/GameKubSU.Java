package game.engine;

public final class Renderer {
	protected boolean updated;
	
	public void tick()
	{
		
	}
}
