package game.engine;

import game.model.World;

public class Runner {
	protected Settings settings;
	protected World world;
	protected Renderer renderer;
	protected AIListener ailistener;
	protected Physics physics;
	
	public static void main(String[] args) {
		//TODO
	}

}
