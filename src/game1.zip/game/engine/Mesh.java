package game.engine;

public class Mesh {
	public int x,y;
	public int w,h;
	public int r;
	public int type;

	public static void main(String[] args) {
	}

}
