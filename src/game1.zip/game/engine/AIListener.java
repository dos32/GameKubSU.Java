package game.engine;

import game.model.World;

import java.net.*;


public final class AIListener {//AIImplementer
	public int port;
	public String ip;
	public World world;
	
	public void sendRequest()
	{
		//TODO
	}
	
	public void getResponse()
	{
		//TODO
	}
	
	public void tick()
	{
		//TODO
	}
}
