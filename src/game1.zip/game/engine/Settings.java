package game.engine;

public final class Settings {
	public AIListenerSettings Listener= new AIListenerSettings();
}

final class AIListenerSettings {
	public static int timeout= 5000;
	public static int port= 4000;
	public static String ip= "127.0.0.1";
}

final class WorldSettings {
	public static double width= 1000.0d, height=600.0d;
}
