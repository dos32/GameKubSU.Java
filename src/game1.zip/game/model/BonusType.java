package game.model;

public enum BonusType {
	FLAG,
	MED_KIT,
	REPAIR_KIT
}
