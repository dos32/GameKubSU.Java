package game.model;

import java.awt.Color;

import game.utils.Vector;

public class Car extends CircleShapeUnit {
	protected int playerId;
	protected String playerName;
	protected boolean isTeammate;
	protected Color color;
	
	//AI's controllers
	protected double motorPower;
	protected double controlTurn;

}
