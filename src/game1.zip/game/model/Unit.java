package game.model;

import game.utils.*;

public abstract class Unit {
	protected Vector position;
	protected Vector speed;
	protected Vector direction;
	protected boolean isStatic;
	protected boolean noCollision;
	protected int id;
	protected abstract double getMass();
	
	public Unit()
	{
		position=new Vector();
		speed=new Vector();
		direction=new Vector();
	}
	
	public Unit(Vector position, Vector speed, Vector direction)
	{
		//TODO
	}
	
	public Vector getDirection()
	{
		return direction;
	}
	
	public abstract double getDepth(Vector v);
	
	public abstract Vector getNorm(Vector v);
	
	public abstract void getMesh();//or Draw(Canvas c);
}
