package game.model;

import game.utils.Vector;

public class CircleShapeUnit extends Unit {

	@Override
	public double getDepth(Vector v) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Vector getNorm(Vector v) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void getMesh() {
		// TODO Auto-generated method stub
		
	}
}
