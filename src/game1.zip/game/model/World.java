package game.model;

public class World {
	public double width, height;
	public Unit[] units;
	
	public static void main(String[] args) {
		//TODO
	}
	
	public void tick()
	{
		//TODO
	}

}
